import seaborn as sns; sns.set()
import random
import numpy as np
import matplotlib.pyplot as plt
from JS_Env.operator_choose_rule import action_translator
import pandas as pd
import os
import pickle
from RL_Env.Agent_Env2 import Env


def test_model(Agent,env,model_path):
    C=[]
    Agent.load_model(model_path)
    for i in range(100):
        state, done = env.reset()
        ep_reward = 0
        while True:
            action = Agent.test_action(state)
            Job_i = action_translator(action, env)
            next_state, reward, done = env.step(Job_i)
            ep_reward += reward
            if done == True:
                fitness = env.SF.C_max
                C.append(fitness)
                break
    return C

def dispatching_rule(env,a):
    C=[]
    for i in range(100):
        state, done = env.reset()
        ep_reward = 0
        while True:
            action = a
            Job_i = action_translator(a, env)
            next_state, reward, done = env.step(Job_i)
            ep_reward += reward
            if done == True:
                fitness = env.SF.C_max
                C.append(fitness)
                break
    return C

def Random_action(env):
    C=[]
    for i in range(100):
        state, done = env.reset()
        ep_reward = 0
        while True:
            action = random.randint(0,3)
            Job_i = action_translator(action, env)
            next_state, reward, done = env.step(Job_i)
            ep_reward += reward
            if done == True:
                fitness = env.SF.C_max
                C.append(fitness)
                break
    return C

if __name__ == '__main__':

    from Instance.Text_extract import data
    from Single_RL.DQN_series.DQN import DQN
    from Single_RL.Params import args
    import time

    model_path = r'C:\Users\Administrator\PycharmProjects\RJSP_singleRL\Single_RL\model_save_64\prTrue\CNN_duelling\ddqnTrue\128_0.0001_50_100000_0.98\step4500'

    from Instance.Test1 import Generate

    # # model_path = r'C:\Users\Administrator\PycharmProjects\RJSP_singleRL\Single_RL\model_save2\prFalse\CNN_DNN\ddqnFalse\128_0.0001_50_500000_0.95\step3500'
    C = ["C2"]
    K = ['11','21','31','41', '51', '61', '71', '81', '91', '101', "12", '22', '32', '42', '52', '62', '72', '82',
         '92', '102',
         "13", '23', '33', '43', '53', '63', '73', '83', '93', '103', "14", '24', '34', '44', '54', '64', '74', '84',
         '94', '104']
    Basline=[130,143,142,198,130,153,129,196,178,188,98,86,114,129,98,123,92,172,123,154,109,98,103,155,109,128,93,172,119,158,168,169,167,242,168,189,156,251,181,246]
    li=[]
    li2=[]
    li3=[]
    for Ci in C:
        for Ki in K:
            if "7" not in Ki and "104" not in Ki:
                hi=K.index(Ki)
                print(Ci,Ki)
                f = r'C:\Users\Administrator\PycharmProjects\RJSP_singleRL/Instance/Bilge_Ulusoy' + '/' + Ci + '/' + 'E' + Ki + '.pkl'

                n, m = 6,4
                PT, agv_trans, MT = Generate(n, m)
                agv_num = 2

                for Mi in MT:
                    Mi.append(m)
                for Pi in PT:
                    Pi.append(0)
                # n, m, PT, agv_trans, MT, agv_num = data(f)
                #
                print(n, m, PT, agv_trans, MT, agv_num )
                env = Env(n, m, agv_num, PT, MT, agv_trans, m)
                env.reset()
                args.max_o_len = 5
                # print(args.max_o_len)
                args.n = 6
                args.NUM_ACTIONS=7

                args.PRE =True
                args.Network_type ='CNN_duelling'
                args.DDQN = True
                args.GAMMA = 0.97
                args.BATCH_SIZE = 128
                args.LR = 0.0001
                args.Q_NETWORK_ITERATION = 50
                args.MEMORY_CAPACITY = 500000
                Agent = DQN(args)

                t1=time.time()
                C1=test_model(Agent,env,model_path)
                t2=time.time()
                print("run time:",t2-t1)
                C=[]
                C.append(C1)
                for i in range(7):
                    C.append(dispatching_rule(env,i))
                C.append(Random_action(env))


                Lis=[min(C[0]),min(C[1]),min(C[2]),min(C[3]),min(C[4]),min(C[5]),min(C[6]),min(C[7]),min(C[8])]
                print(min(Lis))
                LQQ=min(Lis)
                li.append(LQQ)
                MQQQ=[sum(C[0])/len(C[0]), sum(C[1])/len(C[1]), sum(C[2])/len(C[2]),
                      sum(C[3])/len(C[3]),sum(C[4])/len(C[4]),sum(C[5])/len(C[5]),sum(C[6])/len(C[6]),sum(C[7])/len(C[7]),sum(C[8])/len(C[8])]
                mee=min(MQQQ)
                li2.append(mee)

                # print(Basline[hi])
                Np=(Basline[hi]-LQQ)/Basline[hi]
                li3.append(Np)
                print("This is NP",Np)
                C=np.array(C)
                C=C.T
                df = pd.DataFrame(C)
                df.columns=['Agent','LRTP','SRTP','SPTP','LPTP','MOR','LOR','STD','Random_rule']

    # sns.boxplot(data=df.iloc[:,0:9])
    # plt.xlabel('Rule series')
    # plt.ylabel('makespan')
    # plt.show()
    # plt.legend(['Agent','action 1','action 2','action3','action4','random'])
    # plt.show()

    print(li)
    print(li2)
    print(li3)


