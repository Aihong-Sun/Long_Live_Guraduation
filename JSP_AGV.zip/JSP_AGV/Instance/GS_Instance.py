import pickle
import numpy as np

def Instance(name,file_name='self_GeneIns'):
    file=r'C:\Users\Administrator\PycharmProjects\RJSP_singleRL\Instance'+'/'+file_name
    f=file+'/'+name+'.pkl'
    with open(f, "rb") as fb:
        Ins= pickle.load(fb)
    n,m,agv_num,PT,MT,TT=Ins['n'],Ins['m'],Ins['agv_num'],Ins['processing_time'],Ins['Processing_machine'],Ins['travle_Matrix']
    return  n,m,agv_num,PT,MT,TT
