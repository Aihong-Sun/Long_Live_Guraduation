from JSP_AGV.JSP_AGV_Env.AGV import AGV
from JSP_AGV.JSP_AGV_Env.machine import Machine
from JSP_AGV.JSP_AGV_Env.Job import Job

#绘图颜色
colors=[ 'yellow','purple','orange', 'green', 'rosybrown','papayawhip', 'aqua', 'lightblue','aquamarine',
         'azure', 'beige', 'bisque', 'blanchedalmond', 'blue',
        'blueviolet', 'brown', 'burlywood', 'cadetblue', 'chartreuse', 'chocolate', 'coral', 'cornflowerblue',
        'cornsilk', 'crimson', 'cyan', 'darkblue', 'darkcyan', 'darkgoldenrod', 'darkgray', 'darkgreen',
        'darkkhaki', 'darkmagenta', 'darkolivegreen', 'darkorange', 'darkorchid', 'darkred', 'darksalmon',
        'darkseagreen', 'darkslateblue', 'darkslategray', 'darkturquoise', 'darkviolet', 'deeppink',
        'deepskyblue', 'dimgray', 'dodgerblue', 'firebrick', 'floralwhite', 'forestgreen', 'fuchsia',
        'gainsboro', 'ghostwhite', 'gold', 'goldenrod', 'gray', 'green', 'greenyellow', 'honeydew',
        'hotpink', 'indianred', 'indigo', 'ivory', 'khaki', 'lavender', 'lavenderblush', 'lawngreen',
        'lemonchiffon', 'lightblue', 'lightcoral', 'lightcyan', 'lightgoldenrodyellow', 'lightgreen',
        'lightgray', 'lightpink', 'lightsalmon', 'lightseagreen', 'lightskyblue', 'lightslategray',
        'lightsteelblue', 'lightyellow', 'lime', 'limegreen', 'linen', 'magenta', 'maroon', 'mediumaquamarine',
        'mediumblue', 'mediumorchid', 'mediumpurple', 'mediumseagreen', 'mediumslateblue', 'mediumspringgreen',
        'mediumturquoise', 'mediumvioletred', 'midnightblue', 'mintcream', 'mistyrose', 'moccasin', 'navajowhite',
        'navy', 'oldlace', 'olive', 'olivedrab', 'orange', 'orangered', 'orchid', 'palegoldenrod', 'palegreen',
        'paleturquoise', 'palevioletred', 'papayawhip', 'peachpuff', 'peru', 'pink', 'plum', 'powderblue', 'purple',
        'red', 'rosybrown', 'royalblue', 'saddlebrown', 'salmon', 'sandybrown', 'seagreen', 'seashell', 'sienna',
        'silver', 'skyblue', 'slateblue', 'slategray', 'snow', 'springgreen', 'steelblue', 'tan', 'teal', 'thistle',
        'tomato', 'turquoise', 'violet', 'wheat', 'white', 'whitesmoke', 'yellow', 'yellowgreen']


class RJSP:
    def __init__(self,n,m,agv_num,PT,MT,TT,L_U):
        self.n,self.m,self.agv_num=n,m,agv_num
        self.PT=PT
        self.MT=MT
        self.TT=TT
        self.L_U=L_U
        self.Jobs=[]
        self.C_max=0

    def reset(self):
        self.Jobs = []
        for i in range(self.n):
            Ji = Job(i,colors[i],self.PT[i], self.MT[i], self.L_U)
            self.Jobs.append(Ji)
        self.Machines = []
        for j in range(self.m+1):
            Mi = Machine(j)
            self.Machines.append(Mi)
        self.AGVs = []
        for k in range(self.agv_num):
            agv = AGV(k, self.L_U)
            self.AGVs.append(agv)

    def VAA_decode(self,Ji):
        Ji=self.Jobs[Ji]
        J_end,J_site,op_t,op_m=Ji.get_info()
        J_m=self.Machines[op_m]
        best_agv=None
        min_tf=99999
        best_s,best_e,t1,t2=None,None,None,None
        for agv in self.AGVs:
            trans1=self.TT[agv.cur_site][J_site]
            trans2=self.TT[J_site][op_m]
            start,end=agv.ST(J_end,trans1,trans2)
            if end<min_tf:
                best_s,best_e,t1,t2 = start,end,trans1,trans2
                best_agv=agv
                min_tf=end
        best_agv.update(best_s,t1,t2,J_site,op_m,Ji.idx)
        start=max(best_e,J_m.end)
        J_m.update(start,op_t,Ji.idx,Ji.G_color)
        Jend=start+op_t
        Ji.update(Jend,best_agv,J_m)
        if Jend>self.C_max:
            self.C_max=Jend
