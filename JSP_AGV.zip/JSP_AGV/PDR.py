import random

def FIFO(SF):
    Jobs = [Job for Job in SF.Jobs if not Job.Finished]
    # print('这是lenJob', len(Jobs))
    Remain_t = []
    for Ji in Jobs:
        Remain_t.append(Ji.end)
    srtp = [Jobs[i].idx for i, x in enumerate(Remain_t) if x == min(Remain_t)]
    return random.choice(srtp)

def FOFI(SF):
    Jobs = [Job for Job in SF.Jobs if not Job.Finished]
    # print('这是lenJob', len(Jobs))
    Remain_t = []
    for Ji in Jobs:
        Remain_t.append(Ji.end)
    srtp = [Jobs[i].idx for i, x in enumerate(Remain_t) if x == max(Remain_t)]
    return random.choice(srtp)

def SRTP(SF):
    Remain_t=[]
    for Ji in SF.Jobs:
        if Ji.Finished:
            rt=9999
        else:
            rt=sum(Ji.PT[Ji.cur_op:])
        Remain_t.append(rt)
    srtp=[i for i,x in enumerate(Remain_t) if x==min(Remain_t)]
    # print('这是strp', srtp)
    return random.choice(srtp)

def LRTP(SF):
    Jobs = [Job for Job in SF.Jobs if not Job.Finished]
    # print('这是lenJob', len(Jobs))
    Remain_t = []
    for Ji in Jobs:
        rt = sum(Ji.PT[Ji.cur_op:])
        Remain_t.append(rt)

    srtp = [Jobs[i].idx for i, x in enumerate(Remain_t) if x == max(Remain_t)]
    # print('这是strp',srtp)
    return random.choice(srtp)

def SPTP(SF):
    Jobs = [Job for Job in SF.Jobs if not Job.Finished]
    # print('这是lenJob', len(Jobs))
    Remain_t = []
    for Ji in Jobs:
        rt = Ji.PT[Ji.cur_op]
        Remain_t.append(rt)
    srtp = [Jobs[i].idx for i, x in enumerate(Remain_t) if x == min(Remain_t)]
    # print('这是strp', srtp)
    return random.choice(srtp)

def LPTP(SF):
    Jobs=[Job for Job in SF.Jobs if not Job.Finished]
    # print('这是lenJob',len(Jobs))
    Remain_t = []
    for Ji in Jobs:
        rt = Ji.PT[Ji.cur_op]
        Remain_t.append(rt)
    srtp = [Jobs[i].idx for i, x in enumerate(Remain_t) if x == max(Remain_t)]
    # print('这是strp', srtp)
    return random.choice(srtp)

def MOR(SF):
    Jobs = [Job for Job in SF.Jobs if not Job.Finished]
    # print('这是lenJob',len(Jobs))
    Remain_t = []
    for Ji in Jobs:
        rt = len(Ji.PT)-Ji.cur_op
        Remain_t.append(rt)
    srtp = [Jobs[i].idx for i, x in enumerate(Remain_t) if x == max(Remain_t)]
    # print('这是strp', srtp)
    return random.choice(srtp)

def LOR(SF):
    Jobs = [Job for Job in SF.Jobs if not Job.Finished]
    Remain_t = []
    for Ji in Jobs:
        rt = len(Ji.PT)-Ji.cur_op
        Remain_t.append(rt)
    srtp = [Jobs[i].idx for i, x in enumerate(Remain_t) if x == min(Remain_t)]
    return random.choice(srtp)

def STD(SF):
    Jobs = [Job for Job in SF.Jobs if not Job.Finished]
    # print('这是lenJob',len(Jobs))
    Remain_t = []
    for Ji in Jobs:
        trans=[]
        for agv in SF.AGVs:
            trn=SF.TT[agv.cur_site][Ji.cur_site]
            trans.append(trn)
        Remain_t.append(min(trans))
    srtp = [Jobs[i].idx for i, x in enumerate(Remain_t) if x == min(Remain_t)]
    return random.choice(srtp)