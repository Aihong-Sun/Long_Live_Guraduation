
from JSP_AGV.PDR import *

def action_translator(a,Env):
    SF=Env.SF
    if a==0:
        return SRTP(SF)
    if a==1:
        return LRTP(SF)
    if a==2:
        return SPTP(SF)
    if a==3:
        return LPTP(SF)
    if a==4:
        return MOR(SF)
    if a==5:
        return LOR(SF)
    if a==6:
        return STD(SF)
    if a==7:
        return FIFO(SF)
    if a==8:
        return FOFI(SF)